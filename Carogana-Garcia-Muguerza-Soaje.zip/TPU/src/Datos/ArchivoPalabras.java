package Datos;

import Estructuras.TSBArrayList;
import Estructuras.TSB_OA_Hashtable;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


/**
 *
 * @author a2
 */
public class ArchivoPalabras {

    private File file;
    private TSB_OA_Hashtable<String, Integer> m;
//    TSBArrayList palabraGuardada;
    String linea;
    String unaPalabra;
    String palabra[];
    ArchivoSerializado archTabla, archPalabras;    
    
    public ArchivoPalabras() {
        archTabla = new ArchivoSerializado("hashtable.dat");
//        archPalabras = new ArchivoSerializado("palabras.dat");
        m = (TSB_OA_Hashtable) leerSerializado(archTabla);
//        palabraGuardada = (TSBArrayList) leerSerializado(archPalabras);
        if ( m == null )
            m = new TSB_OA_Hashtable(10);
//        if ( palabraGuardada == null )
//            palabraGuardada = new TSBArrayList();
    }
    
    public void setFile(File file) {
        this.file = file;
        if (file != null)
            leerArchivo();
    }

    private void leerArchivo() {
//        m.clear();
        try {
            Scanner scanner = new Scanner(file,"ISO-8859-1");
            
            while (scanner.hasNextLine()) {
                linea = scanner.nextLine();
                palabra = linea.split(" |-");


                for (int i = 0; i < palabra.length; i++) {
                    unaPalabra = palabra[i];
                    unaPalabra = unaPalabra.toLowerCase();
                    unaPalabra = unaPalabra.replaceAll("[^a-záéíóúñ]+", "");
                    if (unaPalabra.isEmpty()) {
                        continue;
                    }
                    Integer c = m.get(unaPalabra);
                    if (c != null) {
                        m.put(unaPalabra, c + 1);
                    } else {
//                        palabraGuardada.add(unaPalabra);
                        m.put(unaPalabra, 1);
                    }
                }
            } 
            guardar();
        } catch (FileNotFoundException ex) {
            System.out.println("Error al leer el archivo: " + ex.getMessage());
        }
    }

    public String listar() {
        StringBuilder sb = new StringBuilder();
        
        Set<Map.Entry<String, Integer>> se = m.entrySet();
        Iterator<Map.Entry<String, Integer>> it = se.iterator();
        
        while(it.hasNext()) {
            Map.Entry<String, Integer> entry = it.next();
            sb.append(entry.getKey()).append(String.valueOf(" -- " + entry.getValue() + "\n"));
        }
//         for (int i = 0; i < palabraGuardada.size(); i++) {
//            sb.append(palabraGuardada.get(i)).append(String.valueOf(" -- " + m.get(palabraGuardada.get(i)) + "\n"));
//        }
        return String.valueOf(sb);
    }
    
    public int cantidadPalabras() {
        return m.size();
    }
    
    public int buscarPalabra(String palabra) {
        int r;
        if (m.containsKey(palabra) == true)
            r = m.get(palabra);
        else
            r = 0;
        
        return r;
    }

    private Serializable leerSerializado(ArchivoSerializado arch) {
        return (Serializable) arch.read();
    }
    
    private boolean guardar() {
        return archTabla.write(m);// && archPalabras.write(palabraGuardada);
    }
    

}
