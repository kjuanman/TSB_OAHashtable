package Datos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author juan
 */
public class ArchivoSerializado<E> {
    private String archivo;

    public ArchivoSerializado(String nomArchivo) {
        archivo = nomArchivo;
    }
    
    public boolean write(E obj){
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(archivo));
            os.writeObject(obj);
            os.flush();
        } catch(FileNotFoundException e){
            System.out.println("Archivo no encontrado");
            return false;
        } catch(IOException e){
            System.out.println(e.toString());
            return false;
        }
        return true;
    }
    
    public E read(){
        E p=null;
        try {
            FileInputStream is = new FileInputStream(archivo);
            ObjectInputStream os = new ObjectInputStream(is);
            p = (E) os.readObject();
            is.close();
            os.close();
        } catch(FileNotFoundException e){
            System.out.println("Archivo no encontrado");
        } catch(IOException e){
            System.out.println("Error al leer el archivo");
        } catch(ClassNotFoundException e){
            System.out.println("ClassNotFoundException");
        }
        return p;
    }

    
    
}
