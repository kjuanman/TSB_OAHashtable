package Estructuras;

import java.io.Serializable;
import java.util.AbstractSet;
import java.util.AbstractCollection;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;

/**
 *
 * @author pppp
 * @param <K> key
 * @param <V> value
 */
public class TSB_OA_Hashtable<K,V> implements Map<K,V>, Cloneable, Serializable {
    
    private final static int MAX_SIZE = Integer.MAX_VALUE;
    private int initial_capacity;
    private int count;
    private float load_factor;
    private TSB_OAHashtableCasilla table[];
    protected transient int modCount;    
    private transient Set<K> keySet = null;
    private transient Set<Map.Entry<K,V>> entrySet = null;
    private transient Collection<V> values = null;
    
    
    //Constructores
    public TSB_OA_Hashtable()
    {
        this.initial_capacity=11;
        this.load_factor=0.5f;
        this.table = new TSB_OAHashtableCasilla[initial_capacity];
        
        for(int i=0;i<table.length;i++){            
            table[i]=new TSB_OAHashtableCasilla();
        }
        this.count = 0;
    }
    public TSB_OA_Hashtable(int initial_capacity){
        if(esPrimo(initial_capacity) == false){
            initial_capacity = siguientePrimo(initial_capacity);
        }
        this.initial_capacity=initial_capacity;
        this.load_factor=0.5f;
        this.table = new TSB_OAHashtableCasilla[initial_capacity];
        
        for(int i=0;i<table.length;i++){
            table[i]=new TSB_OAHashtableCasilla();
        }
        this.count = 0;
    }
    
    public TSB_OA_Hashtable(int initial_capacity, float load_factor)
    {
        if(esPrimo(initial_capacity) == false){
            initial_capacity = siguientePrimo(initial_capacity);
        }
        if(load_factor <= 0) { load_factor = 0.5f; }
        if(initial_capacity <= 0) { initial_capacity = 11; }
         else
        {
            if(initial_capacity > TSB_OA_Hashtable.MAX_SIZE) 
            {
                initial_capacity = TSB_OA_Hashtable.MAX_SIZE;
            }
        }
        
        this.initial_capacity=initial_capacity;
        this.load_factor=load_factor;
        this.table = new TSB_OAHashtableCasilla[initial_capacity];
        for(int i=0;i<table.length;i++){
            
            table[i]=new TSB_OAHashtableCasilla();
        }
        this.count = 0;
    }
    public TSB_OA_Hashtable(Map<? extends K,? extends V> t)
    {
        this.initial_capacity=11;
        this.load_factor=0.5f;
        this.table = new TSB_OAHashtableCasilla[initial_capacity];
//        for(int i=0;i<table.length;i++){
//            table[i]=new TSB_OAHashtableCasilla();
//        }
        this.count = 0;
        this.putAll(t);
    }
    
    
    //************************ Implementacion de metodos especificados por Map.
    @Override
    public int size() 
    {
        return this.count;
    }
    @Override
    public boolean isEmpty() 
    {
        return (this.count == 0);
    }
    @Override
    public boolean containsKey(Object key) 
    {
        return (this.get((K)key) != null);
    }   
    
    @Override
    public boolean containsValue(Object value)
    {
        return this.contains(value);
    }
    
    /**
     * Retorna el objeto al cual esta asociada la clave key en la tabla, o null 
     * si la tabla no contiene ningun objeto asociado a esa clave.
     * @param key la clave que sera buscada en la tabla.
     * @return el objeto asociado a la clave especificada (si existe la clave) o 
     *         null (si no existe la clave en esta tabla).
     * @throws NullPointerException si key es null.
     * @throws ClassCastException si la clase de key no es compatible con la 
     *         tabla.
     */
    @Override
    public V get(Object key) 
    {
      if(key == null) throw new NullPointerException("get(): parametro null");
      int casillaEnLaQueSeEncuentra = search_for_index((K)key);
      if(casillaEnLaQueSeEncuentra != -1){
          return (V) table[casillaEnLaQueSeEncuentra].getContenido().getValue();
      } 
      return null;     
    }

    @Override
    public V put(K key, V value) {
        if(key == null || value == null) throw new NullPointerException("put(): parametro null");        
        int casillaEnLaQueSeEncuentra = search_for_index((K)key);
        if(casillaEnLaQueSeEncuentra != -1){
            V old = (V) table[casillaEnLaQueSeEncuentra].getContenido().getValue();
            Map.Entry<K, V> x = new Entry(key,value);
            table[casillaEnLaQueSeEncuentra].setContenido(x);
            return old;
        }
        if(this.porcentajeOcupacion() >= this.load_factor) this.rehash();
        return put(key,value,0);       
    }
    
    /**
     * Calcula la ocupacion de la tabla.
     * @return el grado de ocupacion de la tabla entre 0 y 1.
     */
    private float porcentajeOcupacion()
    {
        return (float) this.count / this.table.length;
    } 
    
    /**
     * Sobrecarga del metodo put
     * falta terminarlo
     * @param key
     * @param value
     * @param paso
     * numero de paso
     * @return 
     */
    public V put(K key, V value, int paso){
        Map.Entry<K, V> entry = new Entry<>(key, value);
        int posicion = this.h(entry.hashCode(),paso);
        if ((paso > 0) && (posicion == this.h(entry.hashCode(), 0))) {

			System.out.println("It's not possible to add the key " + key + " in hash table.");
			return null;
		}
        if (this.table[posicion].getFlag() != 0 ) {
			
			this.put(key,value,paso + 1);
		}
		else {

			this.table[posicion].setContenido(entry);
                        this.count++;
                        this.modCount++;
		}
       return null;
    }
    
    /**
     * Elimina de la tabla la clave key (y su correspondiente valor asociado).  
     * El metodo no hace nada si la clave no esta en la tabla. 
     * @param key la clave a eliminar.
     * @return El objeto al cual la clave estaba asociada, o null si la clave no
     *         estaba en la tabla.
     * @throws NullPointerException - if the key is null.
     */
     @Override
    public V remove(Object key) 
    {
       if(key == null) throw new NullPointerException("remove(): parametro null");
       int ik = this.search_for_index((K)key);
       V old = null;
       Map.Entry oldd;
       if(ik != -1)
       {
           oldd = table[ik].removeContenido();
           old = (V)oldd.getValue();
           this.count--;
           this.modCount++;
       }
       
       return old;  
    }
    
    //????????????????????????????????????????????????????????????????
    @Override
    public void putAll(Map<? extends K, ? extends V> m) 
    {
        for(Map.Entry<? extends K, ? extends V> e : m.entrySet())
        {
            put(e.getKey(), e.getValue());
        }
    }
    
    @Override
    public void clear() 
    {
        this.table = new TSB_OAHashtableCasilla[initial_capacity];
        for (int i = 0; i < table.length; i++) {
            table[i] = new TSB_OAHashtableCasilla();
        }
        this.count = 0;
        this.modCount++;
    }
    
    /**
     * Retorna un Set (conjunto) a modo de vista de todas las claves (key)
     * contenidas en la tabla. El conjunto esta respaldado por la tabla, por lo 
     * que los cambios realizados en la tabla seran reflejados en el conjunto, y
     * viceversa. Si la tabla es modificada mientras un iterador esta actuando 
     * sobre el conjunto vista, el resultado de la iteracion sera indefinido 
     * (salvo que la modificacion sea realizada por la operacion remove() propia
     * del iterador, o por la operacion setValue() realizada sobre una entrada 
     * de la tabla que haya sido retornada por el iterador). El conjunto vista 
     * provee metodos para eliminar elementos, y esos metodos a su vez 
     * eliminan el correspondiente par (key, value) de la tabla (a traves de las
     * operaciones Iterator.remove(), Set.remove(), removeAll(), retainAll() 
     * y clear()). El conjunto vista no soporta las operaciones add() y 
     * addAll() (si se las invoca, se lanzara una UnsuportedOperationException).
     * @return un conjunto (un Set) a modo de vista de todas las claves
     *         mapeadas en la tabla.
     */
    @Override
    public Set<K> keySet() 
    {
        if(keySet == null) 
        { 
            // keySet = Collections.synchronizedSet(new KeySet()); 
            keySet = new KeySet();
        }
        return keySet;  
    }
    
    /**
     * Retorna una Collection (coleccion) a modo de vista de todos los valores
     * (values) contenidos en la tabla. La coleccion esta respaldada por la 
     * tabla, por lo que los cambios realizados en la tabla seran reflejados en 
     * la coleccion, y viceversa. Si la tabla es modificada mientras un iterador 
     * esta actuando sobre la coleccion vista, el resultado de la iteracion sera 
     * indefinido (salvo que la modificacion sea realizada por la operacion 
     * remove() propia del iterador, o por la operacion setValue() realizada 
     * sobre una entrada de la tabla que haya sido retornada por el iterador). 
     * La coleccion vista provee metodos para eliminar elementos, y esos metodos 
     * a su vez eliminan el correspondiente par (key, value) de la tabla (a 
     * traves de las operaciones Iterator.remove(), Collection.remove(), 
     * removeAll(), removeAll(), retainAll() y clear()). La coleccion vista no 
     * soporta las operaciones add() y addAll() (si se las invoca, se lanzara 
     * una UnsuportedOperationException).
     * @return una coleccion (un Collection) a modo de vista de todas los 
     *         valores mapeados en la tabla.
     */
    @Override
    public Collection<V> values() 
    {
        if(values==null)
        {
            // values = Collections.synchronizedCollection(new ValueCollection());
            values = new ValueCollection();
        }
        return values;    
    }
    
    /**
     * Retorna un Set (conjunto) a modo de vista de todos los pares (key, value)
     * contenidos en la tabla. El conjunto esta respaldado por la tabla, por lo 
     * que los cambios realizados en la tabla seran reflejados en el conjunto, y
     * viceversa. Si la tabla es modificada mientras un iterador esta actuando 
     * sobre el conjunto vista, el resultado de la iteracion sera indefinido 
     * (salvo que la modificacion sea realizada por la operacion remove() propia
     * del iterador, o por la operacion setValue() realizada sobre una entrada 
     * de la tabla que haya sido retornada por el iterador). El conjunto vista 
     * provee metodos para eliminar elementos, y esos metodos a su vez 
     * eliminan el correspondiente par (key, value) de la tabla (a traves de las
     * operaciones Iterator.remove(), Set.remove(), removeAll(), retainAll() 
     * and clear()). El conjunto vista no soporta las operaciones add() y 
     * addAll() (si se las invoca, se lanzara una UnsuportedOperationException).
     * @return un conjunto (un Set) a modo de vista de todos los objetos 
     *         mapeados en la tabla.
     */
    @Override
    public Set<Map.Entry<K, V>> entrySet() 
    {
        if(entrySet == null) 
        { 
            // entrySet = Collections.synchronizedSet(new EntrySet()); 
            entrySet = new EntrySet();
        }
        return entrySet;
    }
    
    //************************ Redefinicion de metodos heredados desde Object.
    
    @Override
    protected Object clone() throws CloneNotSupportedException 
    {
        TSB_OA_Hashtable<K, V> t = (TSB_OA_Hashtable<K, V>)super.clone();
        t.table = new TSB_OAHashtableCasilla[initial_capacity];
        for(int i=0;i<t.size();i++){
            
            t.table[i]=(TSB_OAHashtableCasilla)table[i].clone() ;
        }
        
        t.keySet = null;
        t.entrySet = null;
        t.values = null;
        t.modCount = 0;
        return t;
    }
    
    /**
     * Determina si esta tabla es igual al objeto espeficicado.
     * @param obj el objeto a comparar con esta tabla.
     * @return true si los objetos son iguales.
     */
    @Override
    public boolean equals(Object obj) 
    {
    
        if(!(obj instanceof Map)) { return false; }
        
        Map<K, V> t = (Map<K, V>) obj;
        if(t.size() != this.size()) { return false; }
        

        try 
        {
            for(int j=0;j<table.length;j++){
                if(table[j].getFlag()==1){
                    K key = (K) table[j].getContenido().getKey();
                    if(! table[j].getContenido().equals(t.get(key))) return false;
                }
            }
        } 
        
        catch (ClassCastException | NullPointerException e) 
        {
            return false;
        }

        return true;
    }
    
    /**
     * Retorna un hash code para la tabla completa.
     * @return un hash code para la tabla.
     */
    @Override
    public int hashCode() 
    {
        if(this.isEmpty()) {return 0;}
        
        int hc = 0;
        for(Map.Entry<K, V> entry : this.entrySet())
        {
            hc += entry.hashCode();
        }
        
        return hc;
    }
    
     @Override
       public String toString() 
    {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int i=0;i<this.table.length;i++){
            if(table[i].getFlag()==1){
                sb.append(table[i].getContenido().toString());
                sb.append(" ; ");
            }else{
             //   sb.append(" _ ");
            }
           // sb.append(" ; ");
        }            
        sb.append("]");
        return sb.toString();
    }
    
    //************************ Metodos especificos de la clase.

    /**
     * Determina si alguna clave de la tabla esta asociada al objeto value que
     * entra como parametro. Equivale a containsValue().
     * @param value el objeto a buscar en la tabla.
     * @return true si alguna clave esta asociada efectivamente a ese value.
     */
    public boolean contains(Object value)
    {
        if(value == null) return false;
        
        for(int i=0;i<table.length;i++){
            if(table[i].getFlag()==1){
                if(table[i].getContenido().getValue().equals(value)){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Incrementa el tamaño de la tabla y reorganiza su contenido. Se invoca 
     * automaticamente cuando se detecta que la cantidad promedio de nodos por 
     * lista supera a cierto el valor critico dado por (10 * load_factor). Si el
     * valor de load_factor es 0.8, esto implica que el limite antes de invocar 
     * rehash es de 8 nodos por lista en promedio, aunque seria aceptable hasta 
     * unos 10 nodos por lista.
     */
    protected void rehash()
    {
        int new_length = table.length * 2 + 1;
        if(new_length > TSB_OA_Hashtable.MAX_SIZE) 
        { 
            new_length = TSB_OA_Hashtable.MAX_SIZE;
        }
        if(! esPrimo(new_length)) new_length=siguientePrimo(new_length);
        
        TSB_OAHashtableCasilla tablaAuxiliar[] = this.table;
        TSB_OAHashtableCasilla nuevaTabla[] = new TSB_OAHashtableCasilla[new_length];
        for(int i=0;i<nuevaTabla.length;i++){
            
            nuevaTabla[i]=new TSB_OAHashtableCasilla();
        }
        this.table=nuevaTabla;
        
        for(int i=0;i<tablaAuxiliar.length;i++){
            if(tablaAuxiliar[i].getFlag()==1){
                Map.Entry x=tablaAuxiliar[i].getContenido();
                put((K)x.getKey(), (V)x.getValue());
            }
        }       
        this.modCount++;
        
    }
    
    //************************ Metodos privados.
    
   /**Hash function
	 * Quadratic probing.
         * @hashcode 
         * el hashcode, seria el valor de la clave despues de pasar por el metodo hashcode
         * @Param: int i
         * paso
	 */
	public int h(int hashcode, int i) {
                if(hashcode<0) hashcode*=-1;
                int h = (hashcode + (i * i)) % this.table.length;
		return h;
	}
    
    /*
     * Busca en la lista un objeto Entry cuya clave coincida con key.
     * Si lo encuentra, retorna su posicion. Si no lo encuentra, retorna -1.
     */
    private int search_for_index(K key)
    {
        for(int i=0;i<table.length;i++){
            if(table[i].getFlag()==1){
                if(table[i].getContenido().getKey().equals(key)) return i; 
            }
        }       
        return -1;
    }
    
    //Metodos para asegurar que el tamaño de la tabla sea un numero primo
        private final int siguientePrimo(int n){
        if(n%2 == 0) n++;
        for(;!esPrimo(n);n+=2);
        return n;
    }
    
    private final boolean esPrimo(int n) {
        //checkea si n es multiplo de 2
        if (n%2==0) return false;
        //si no, solamente verifica los impares
        for(int i=3;i*i<=n;i+=2) {
            if(n%i==0)
                return false;
        }
        return true;
    }


    
    //************************ Clases Internas.
    
    /*
     * Clase interna que representa los pares de objetos que se almacenan en la
     * tabla hash: son instancias de esta clase las que realmente se guardan en 
     * en cada una de las listas del arreglo table que se usa como soporte de 
     * la tabla. Lanzara una IllegalArgumentException si alguno de los dos 
     * parametros es null.
     */
    private class Entry<K, V> implements Map.Entry<K, V> , Serializable
    {
        private K key;
        private V value;
        
        public Entry(K key, V value) 
        {
            if(key == null || value == null)
            {
                throw new IllegalArgumentException("Entry(): parametro null...");
            }
            this.key = key;
            this.value = value;
        }
        
        @Override
        public K getKey() 
        {
            return key;
        }

        @Override
        public V getValue() 
        {
            return value;
        }

        @Override
        public V setValue(V value) 
        {
            if(value == null) 
            {
                throw new IllegalArgumentException("setValue(): parametro null...");
            }
                
            V old = this.value;
            this.value = value;
            return old;
        }
       
        
        /**
         * Metodo hashcode, transforma una clave no importa el tipo de objeto en una clave numerica,
         * esto sirve para lograr el polimorfismo
         * @return 
         */
        @Override
        public int hashCode() 
        {
            int hash = 7;
            hash = 61 * hash + Objects.hashCode(this.key);
            hash = 61 * hash + Objects.hashCode(this.value);            
            return hash;
        }

        @Override
        public boolean equals(Object obj) 
        {
            if (this == obj) { return true; }
            if (obj == null) { return false; }
            if (this.getClass() != obj.getClass()) { return false; }
            
            final Entry other = (Entry) obj;
            if (!Objects.equals(this.key, other.key)) { return false; }
            if (!Objects.equals(this.value, other.value)) { return false; }            
            return true;
        }       
        
        @Override
        public String toString()
        {
            return "(" + key.toString() + ", " + value.toString() + ")";
        }
    }
    
    
    
    /*
     * Clase interna que representa una vista de todas los Claves mapeadas en la
     * tabla: si la vista cambia, cambia tambien la tabla que le da respaldo, y
     * viceversa. La vista es stateless: no mantiene estado alguno (es decir, no 
     * contiene datos ella misma, sino que accede y gestiona directamente datos
     * de otra fuente), por lo que no tiene atributos y sus metodos gestionan en
     * forma directa el contenido de la tabla. Estan soportados los metodos para
     * eliminar un objeto (remove()), eliminar todo el contenido (clear) y la  
     * creacion de un Iterator (que incluye el metodo Iterator.remove()).
     */    
    private class KeySet extends AbstractSet<K> 
    {
        @Override
        public Iterator<K> iterator() 
        {
            return new KeySetIterator();
        }
        
        @Override
        public int size() 
        {
            return TSB_OA_Hashtable.this.count;
        }
        
        @Override
        public boolean contains(Object o) 
        {
            return TSB_OA_Hashtable.this.containsKey(o);
        }
        
        @Override
        public boolean remove(Object o) 
        {
            return (TSB_OA_Hashtable.this.remove(o) != null);
        }
        
        @Override
        public void clear() 
        {
            TSB_OA_Hashtable.this.clear();
        }
        
        private class KeySetIterator implements Iterator<K>
        {
           private int last_entry;
            // indice del elemento actual en el iterador (el que fue retornado 
            // la ultima vez por next() y sera eliminado por remove())... 
            private int current_entry;
            // flag para controlar si remove() esta bien invocado...
            private boolean next_ok;
            // el valor que deberia tener el modCount de la tabla completa...
            private int expected_modCount;
            
            /*
             * Crea un iterador comenzando por el primer indice. Activa el 
             * mecanismo fail-fast.
             */
            public KeySetIterator()
            {
                this.current_entry=-1;
                this.next_ok=false;
                this.expected_modCount =TSB_OA_Hashtable.this.modCount;
            }

            /*
             * Determina si hay al menos un elemento en la tabla que no haya 
             * sido retornado por next(). 
             */
            @Override
            public boolean hasNext() 
            {
                if(TSB_OA_Hashtable.this.isEmpty()) { return false; }
                if(current_entry >= table.length) { return false; }
                
                if(current_entry==-1) current_entry++;
                for(int i=current_entry;i<table.length;i++){
                    if(table[i].getFlag()==1)return true;
                }
                return false;
            }

            /*
             * Retorna el siguiente elemento disponible en la tabla.
             */
            @Override
            public K next() 
            {
                 if(TSB_OA_Hashtable.this.modCount != expected_modCount)
                {    
                    throw new ConcurrentModificationException("next(): modificacion inesperada de tabla...");
                }
                
                if(!hasNext()) 
                {
                    throw new NoSuchElementException("next(): no existe el elemento pedido...");
                }
                last_entry=current_entry;
                while(current_entry < table.length){                    
                    if(table[current_entry].getFlag()==1){
                        next_ok = true;
                        return (K) table[current_entry].getContenido().getKey();
                    }
                    current_entry++;
                }                               
                return (K) table[current_entry].getContenido().getKey();
            }
            
            /*
             * Remueve el elemento actual de la tabla, dejando el iterador en la
             * posicion anterior al que fue removido. El elemento removido es el
             * que fue retornado la ultima vez que se invoco a next(). El metodo
             * solo puede ser invocado una vez por cada invocacion a next().
             */
            @Override
            public void remove() 
            {
               if(!next_ok) 
                { 
                    throw new IllegalStateException("remove(): debe invocar a next() antes de remove()..."); 
                }

               TSB_OA_Hashtable.this.table[current_entry].removeContenido();
               // avisar que el remove() valido para next() ya se activo...
               current_entry=last_entry;
                next_ok = false;
                // la tabla tiene un elementon menos...
                TSB_OA_Hashtable.this.count--;
                // fail_fast iterator: todo en orden...
                TSB_OA_Hashtable.this.modCount++;
                expected_modCount++;               
            }     
        }
    }
    
    /*
     * Clase interna que representa una vista de todos los VALORES mapeados en la tabla
     */         
    private class ValueCollection extends AbstractCollection<V> 
    {
        @Override
        public Iterator<V> iterator() 
        {
            return new ValueCollectionIterator();
        }
        
        @Override
        public int size() 
        {
            return TSB_OA_Hashtable.this.count;
        }
        
        @Override
        public boolean contains(Object o) 
        {
            return TSB_OA_Hashtable.this.containsValue(o);
        }
        
        @Override
        public void clear() 
        {
            TSB_OA_Hashtable.this.clear();
        }
        
        private class ValueCollectionIterator implements Iterator<V>
        {
            
            // indice del elemento actual en el iterador (el que fue retornado 
            // la ultima vez por next() y sera eliminado por remove())...
            private int current_entry;
            private int last_entry;
            
            // flag para controlar si remove() esta bien invocado...
            private boolean next_ok;
            
            // el valor que deberia tener el modCount de la tabla completa...
            private int expected_modCount;
            
            /*
             * Crea un iterador comenzando en la primera lista. Activa el 
             * mecanismo fail-fast.
             */
            public ValueCollectionIterator()
            {
                current_entry = -1;
                next_ok = false;
                expected_modCount = TSB_OA_Hashtable.this.modCount;
            }

            /*
             * Determina si hay al menos un elemento en la tabla que no haya 
             * sido retornado por next(). 
             */
            @Override
            public boolean hasNext() 
            {                
                if(TSB_OA_Hashtable.this.isEmpty()) { return false; }
                if(current_entry >= table.length) { return false; }
                
                if(current_entry==-1) current_entry++;
                for(int i=current_entry;i<table.length;i++){
                    if(table[i].getFlag()==1)return true;
                }
                return false;
            }

            /*
             * Retorna el siguiente elemento disponible en la tabla.
             */
            @Override
            public V next() 
            {
                 if(TSB_OA_Hashtable.this.modCount != expected_modCount)
                {    
                    throw new ConcurrentModificationException("next(): modificacion inesperada de tabla...");
                }
                
                if(!hasNext()) 
                {
                    throw new NoSuchElementException("next(): no existe el elemento pedido...");
                }
                last_entry=current_entry;
                while(current_entry < table.length){                    
                    if(table[current_entry].getFlag()==1){
                        next_ok = true;
                        return (V) table[current_entry].getContenido().getValue();
                    }
                    current_entry++;
                }                               
                return (V) table[current_entry].getContenido().getValue();
                
            }
            
            /*
             * Remueve el elemento actual de la tabla, dejando el iterador en la
             * posicion anterior al que fue removido. El elemento removido es el
             * que fue retornado la ultima vez que se invoco a next(). El metodo
             * solo puede ser invocado una vez por cada invocacion a next().
             */
            @Override
            public void remove() 
            {               
               if(!next_ok) 
                { 
                    throw new IllegalStateException("remove(): debe invocar a next() antes de remove()..."); 
                }

                TSB_OA_Hashtable.this.table[current_entry].removeContenido();
                // avisar que el remove() valido para next() ya se activo...
                current_entry=last_entry;
                next_ok = false;
                // la tabla tiene un elementon menos...
                TSB_OA_Hashtable.this.count--;
                // fail_fast iterator: todo en orden...
                TSB_OA_Hashtable.this.modCount++;
                expected_modCount++;    
                
            }     
        }
    }
    

    
    /*
     * Clase interna que representa una vista de todos los PARES mapeados en la tabla
     */

    private class EntrySet extends AbstractSet<Map.Entry<K, V>> 
    {

        @Override
        public Iterator<Map.Entry<K, V>> iterator() 
        {
            return new EntrySetIterator();
        }

        @Override
        public int size() 
        {
            return TSB_OA_Hashtable.this.count;
        }

        @Override
        public void clear() 
        {
            TSB_OA_Hashtable.this.clear();
        }
        
        private class EntrySetIterator implements Iterator<Map.Entry<K, V>>
        {           
           // indice del elemento actual en el iterador (el que fue retornado 
            // la ultima vez por next() y sera eliminado por remove())...
            private int current_entry;
            private int last_entry;
                        
            // flag para controlar si remove() esta bien invocado...
            private boolean next_ok;
            
            // el valor que deberia tener el modCount de la tabla completa...
            private int expected_modCount;
            
            /*
             * Crea un iterador comenzando en la primera lista. Activa el 
             * mecanismo fail-fast.
             */
            public EntrySetIterator()
            {
                current_entry = -1;
                next_ok = false;
                expected_modCount = TSB_OA_Hashtable.this.modCount;
            }

            /*
             * Determina si hay al menos un elemento en la tabla que no haya 
             * sido retornado por next(). 
             */
            @Override
            public boolean hasNext() 
            {
                if(TSB_OA_Hashtable.this.isEmpty()) { return false; }
                if(current_entry >= table.length) { return false; }
                
                if(current_entry==-1) current_entry++;
                for(int i=current_entry;i<table.length;i++){
                    if(table[i].getFlag()==1)return true;
                }
                return false;
            }

            /*
             * Retorna el siguiente elemento disponible en la tabla.
             */
            @Override
            public Map.Entry<K, V> next() 
            {
                    if(TSB_OA_Hashtable.this.modCount != expected_modCount)
                {    
                    throw new ConcurrentModificationException("next(): modificacion inesperada de tabla...");
                }
                
                if(!hasNext()) 
                {
                    throw new NoSuchElementException("next(): no existe el elemento pedido...");
                }
                last_entry=current_entry;               
                while(current_entry < table.length){                    
                    if(table[current_entry].getFlag()==1){
                        next_ok = true;
                        current_entry++;
                        return (Entry) table[current_entry-1].getContenido();
                    }
                    current_entry++;
                }                               
                return (Entry) table[current_entry].getContenido();
            }
            
            /*
             * Remueve el elemento actual de la tabla, dejando el iterador en la
             * posicion anterior al que fue removido. El elemento removido es el
             * que fue retornado la ultima vez que se invoco a next(). El metodo
             * solo puede ser invocado una vez por cada invocacion a next().
             */
            @Override
            public void remove() 
            {
               
               if(!next_ok) 
                { 
                    throw new IllegalStateException("remove(): debe invocar a next() antes de remove()..."); 
                }

                TSB_OA_Hashtable.this.table[current_entry].removeContenido();
                // avisar que el remove() valido para next() ya se activo...
                current_entry=last_entry;
                next_ok = false;
                // la tabla tiene un elementon menos...
                TSB_OA_Hashtable.this.count--;
                // fail_fast iterator: todo en orden...
                TSB_OA_Hashtable.this.modCount++;
                expected_modCount++;    
            }     
        }
    }     
}