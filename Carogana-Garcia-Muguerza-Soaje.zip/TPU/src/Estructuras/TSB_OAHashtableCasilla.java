package Estructuras;

import java.io.Serializable;
import java.util.Map;

public class TSB_OAHashtableCasilla implements Serializable {

    private int flag;
    private Map.Entry contenido;

    public TSB_OAHashtableCasilla() {
        this.flag = 0;
        this.contenido = null;
    }

    public TSB_OAHashtableCasilla(Map.Entry contenido) {
        this.flag = 1;
        this.contenido = contenido;
    }

    public int getFlag() {
        return flag;
    }

    public Map.Entry getContenido() {
        return contenido;
    }

    public void setContenido(Map.Entry contenido) {
        this.contenido = contenido;
        this.flag = 1;
    }

    public Map.Entry removeContenido() {
        Map.Entry old = this.contenido;
        this.contenido = null;
        this.flag = 2;
        return old;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        TSB_OAHashtableCasilla c = (TSB_OAHashtableCasilla) super.clone();
        return c;
    }

    public String toString() {
        if (contenido!=null) {
            return contenido.getValue().toString();
        } else {
            return "TSB_OAHashtableCasilla esta vacio";
        }
    }

}
