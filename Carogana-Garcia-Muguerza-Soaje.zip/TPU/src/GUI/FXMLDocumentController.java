package GUI;

import Datos.ArchivoPalabras;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

/**
 *
 * @author Martinnc4
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button btn_cargar;
    @FXML
    private Button btn_limpiar;
    @FXML
    private Button btn_buscar;
    @FXML
    private TextField txt_busqueda;
    @FXML
    private Label lbl_busqueda;
    private ArchivoPalabras archivo;
    @FXML
    private Label lbl_ruta;
    @FXML
    private TextArea txt_lista;
    @FXML
    private Label lbl_cantidadPalabras;
    
    @FXML
    private void handleButtonCargar(ActionEvent event) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Abrir archivo de texto");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos de texto (*.txt)", "*.txt"));
        File file = chooser.showOpenDialog(null);
        if (file != null) {
            limpiarBusqueda();
            lbl_ruta.setText("Ruta del archivo: " + file.getAbsolutePath());
            archivo.setFile(file);
            txt_lista.setText(archivo.listar());
            lbl_cantidadPalabras.setText("Cantidad de palabras listadas: " + archivo.cantidadPalabras());
        }
    }
    
    @FXML
    private void handleButtonBuscar(ActionEvent event) {
        if (txt_busqueda.getText().isEmpty()) {
            lbl_busqueda.setText("No se ingreso ninguna palabra");
        } else {
            lbl_busqueda.setText(String.valueOf(archivo.buscarPalabra(txt_busqueda.getText()))); 
        }

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        archivo = new ArchivoPalabras();
        txt_lista.setText(archivo.listar());
        lbl_cantidadPalabras.setText("Cantidad de palabras listadas: " + archivo.cantidadPalabras());
    }    
    
        @FXML
    private void handleButtonLimpiar(ActionEvent event) {
        limpiarBusqueda();
    }
    
    private void limpiarBusqueda()
    {
        txt_busqueda.setText("");
        lbl_busqueda.setText("Ingrese la palabra que desea buscar: ");    
    }
    
}
